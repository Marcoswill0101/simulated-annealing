# simulated-annealing
Implementação em Java do Simulated Annealing
