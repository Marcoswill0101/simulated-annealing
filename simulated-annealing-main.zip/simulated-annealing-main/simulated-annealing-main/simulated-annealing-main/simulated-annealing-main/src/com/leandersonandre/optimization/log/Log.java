package com.leandersonandre.optimization.log;

public class Log {

    public static void info(String message) {
       // System.out.println("INFO: "+message);
    }

}
