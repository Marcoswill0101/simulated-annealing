package com.leandersonandre.optimization.sa;

public class SAParameters {
}
