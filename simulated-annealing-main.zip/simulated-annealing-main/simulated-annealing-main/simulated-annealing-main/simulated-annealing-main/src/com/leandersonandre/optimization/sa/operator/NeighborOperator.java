package com.leandersonandre.optimization.sa.operator;

public interface NeighborOperator {

    void generateNeighbor(double x[]);

}
